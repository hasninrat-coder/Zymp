# Zymp
Open this folder in Android Studio (Koala or newer, JDK 17). Let Gradle sync (Android Studio creates the wrapper JAR),
then Build > Build APK(s), or run `./gradlew assembleDebug` -> app/build/outputs/apk/debug/app-debug.apk
