package com.zymp.musicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zymp.musicplayer.ui.*

sealed interface Screen {
    data object Home : Screen
    data object Eq : Screen
    data object Settings : Screen
    data object Lyrics : Screen
    data class Detail(val kind: String, val key: String) : Screen
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        setContent {
            val accentIdx by vm.accent.collectAsStateWithLifecycle()
            val amoled by vm.amoled.collectAsStateWithLifecycle()
            ZympTheme(Accents[accentIdx.coerceIn(0, Accents.lastIndex)], amoled) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Root(vm) }
            }
        }
    }
}

private val audioPerm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

@Composable
private fun Root(vm: MainViewModel) {
    val ctx = LocalContext.current
    fun has() = ContextCompat.checkSelfPermission(ctx, audioPerm) == PackageManager.PERMISSION_GRANTED
    var granted by remember { mutableStateOf(has()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = has(); if (granted) vm.load()
    }
    val perms = remember {
        buildList { add(audioPerm); if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS) }.toTypedArray()
    }
    LaunchedEffect(Unit) { if (granted) vm.load() else launcher.launch(perms) }

    if (!granted) {
        Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Zymp", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text("Zymp needs access to the audio files on your device to build your library.", textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))
            Button({ launcher.launch(perms) }) { Text("Grant access") }
        }
        return
    }

    val cur by vm.current.collectAsStateWithLifecycle()
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    var expanded by remember { mutableStateOf(false) }
    fun push(s: Screen) { stack.add(s) }
    fun pop() { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    BackHandler(enabled = expanded || stack.size > 1) { if (expanded) expanded = false else pop() }

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                AnimatedContent(stack.last(), transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(200)) }, label = "nav") { s ->
                    when (s) {
                        Screen.Home -> HomeScreen(vm, { k, key -> push(Screen.Detail(k, key)) }, { push(Screen.Settings) })
                        is Screen.Detail -> DetailScreen(vm, s.kind, s.key, ::pop)
                        Screen.Eq -> EqualizerScreen(vm, ::pop)
                        Screen.Lyrics -> LyricsScreen(vm, ::pop)
                        Screen.Settings -> SettingsScreen(vm, ::pop) { push(Screen.Eq) }
                    }
                }
            }
            if (cur != null) MiniPlayer(vm) { expanded = true }
        }
        AnimatedVisibility(expanded && cur != null, enter = slideInVertically { it }, exit = slideOutVertically { it }) {
            NowPlayingScreen(
                vm, onClose = { expanded = false },
                onEq = { expanded = false; push(Screen.Eq) },
                onLyrics = { expanded = false; push(Screen.Lyrics) }
            )
        }
    }
}
