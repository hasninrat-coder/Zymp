@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.zymp.musicplayer.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import com.zymp.musicplayer.data.Store
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

object EqPresets {
    val freqs = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val labels = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
    val builtin: LinkedHashMap<String, FloatArray> = linkedMapOf(
        "Flat" to FloatArray(10),
        "Bass Boost" to floatArrayOf(6f, 5f, 4f, 2.5f, 1f, 0f, 0f, 0f, 0f, 0f),
        "Rock" to floatArrayOf(5f, 4f, 3f, 1f, -1f, -1f, 1f, 3f, 4f, 5f),
        "Pop" to floatArrayOf(-1f, 1f, 3f, 4f, 3f, 0f, -1f, -1f, 1f, 2f),
        "Classical" to floatArrayOf(0f, 0f, 0f, 0f, 0f, 0f, -2f, -2f, -2f, -4f),
        "Jazz" to floatArrayOf(3f, 2f, 1f, 2f, -2f, -2f, 0f, 1f, 2f, 3f),
        "Dance" to floatArrayOf(6f, 5f, 3f, 0f, 0f, -2f, -1f, 1f, 3f, 4f),
        "Vocal" to floatArrayOf(-3f, -3f, -1f, 1f, 3f, 4f, 3f, 2f, 0f, -1f),
        "Acoustic" to floatArrayOf(4f, 4f, 3f, 1f, 1f, 1f, 2f, 3f, 3f, 2f)
    )
}

/** 10-band peaking-biquad equalizer + balance, run on the PCM stream inside ExoPlayer's audio sink. */
class EqProcessor : BaseAudioProcessor() {
    @Volatile var enabled = true
    @Volatile var balance = 0f
    private val gains = FloatArray(10)
    @Volatile private var dirty = true
    private var sampleRate = 44100
    private var channels = 2
    private val coef = Array(10) { DoubleArray(5) }
    private val on = BooleanArray(10)
    private var z1 = DoubleArray(0)
    private var z2 = DoubleArray(0)
    private var pre = 1.0

    fun setGains(g: FloatArray) {
        synchronized(gains) { for (i in 0 until 10) gains[i] = g[i] }
        dirty = true
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount
        z1 = DoubleArray(channels * 10)
        z2 = DoubleArray(channels * 10)
        dirty = true
        return inputAudioFormat
    }

    override fun onFlush() { z1.fill(0.0); z2.fill(0.0) }
    override fun onReset() { z1 = DoubleArray(0); z2 = DoubleArray(0) }

    private fun recompute() {
        dirty = false
        var maxPos = 0f
        for (b in 0 until 10) {
            val g = synchronized(gains) { gains[b] }
            val f = EqPresets.freqs[b].toDouble()
            if (abs(g) < 0.05f || f >= sampleRate / 2.2) { on[b] = false; continue }
            on[b] = true
            if (g > maxPos) maxPos = g
            val a = 10.0.pow(g / 40.0)
            val w0 = 2 * PI * f / sampleRate
            val alpha = sin(w0) / (2 * 1.41)
            val cw = cos(w0)
            val a0 = 1 + alpha / a
            coef[b][0] = (1 + alpha * a) / a0
            coef[b][1] = (-2 * cw) / a0
            coef[b][2] = (1 - alpha * a) / a0
            coef[b][3] = (-2 * cw) / a0
            coef[b][4] = (1 - alpha / a) / a0
        }
        pre = 10.0.pow(-(maxPos * 0.5) / 20.0) // headroom against clipping
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        if (dirty) recompute()
        val active = enabled && on.any { it }
        val bal = balance
        val lGain = if (bal > 0f) 1f - bal else 1f
        val rGain = if (bal < 0f) 1f + bal else 1f
        val frames = size / (2 * channels)
        for (f in 0 until frames) {
            for (c in 0 until channels) {
                var x = inputBuffer.short.toDouble()
                if (active) {
                    x *= pre
                    val base = c * 10
                    for (b in 0 until 10) {
                        if (!on[b]) continue
                        val k = coef[b]
                        val i = base + b
                        val y = k[0] * x + z1[i]
                        z1[i] = k[1] * x - k[3] * y + z2[i]
                        z2[i] = k[2] * x - k[4] * y
                        x = y
                    }
                }
                if (channels == 2) x *= if (c == 0) lGain else rGain
                out.putShort(x.coerceIn(-32768.0, 32767.0).toInt().toShort())
            }
        }
        while (inputBuffer.hasRemaining()) inputBuffer.get()
        out.flip()
    }
}

/** Process-wide audio-effect state shared by the UI and the playback service. */
object Fx {
    val eq = EqProcessor()
    @Volatile var sleepAtMs = 0L
    @Volatile var crossfadeMs = 0L
    var enabled = true
    var gains = FloatArray(10)
    var bass = 0
    var virt = 0
    var balance = 0f
    var preset = "Flat"
    var bassOk = false
    var virtOk = false
    private var bb: BassBoost? = null
    private var vz: Virtualizer? = null

    fun attach(sessionId: Int) {
        release()
        if (sessionId == 0) return
        try { bb = BassBoost(0, sessionId) } catch (_: Throwable) { bb = null }
        try { vz = Virtualizer(0, sessionId) } catch (_: Throwable) { vz = null }
        bassOk = try { bb?.strengthSupported == true } catch (_: Throwable) { false }
        virtOk = try { vz?.strengthSupported == true } catch (_: Throwable) { false }
        applyEffects()
    }

    fun release() {
        try { bb?.release() } catch (_: Throwable) { }
        try { vz?.release() } catch (_: Throwable) { }
        bb = null; vz = null
    }

    private fun applyEffects() {
        try { bb?.let { if (bassOk) it.setStrength(bass.toShort()); it.enabled = enabled && bass > 0 } } catch (_: Throwable) { }
        try { vz?.let { if (virtOk) it.setStrength(virt.toShort()); it.enabled = enabled && virt > 0 } } catch (_: Throwable) { }
    }

    fun apply(store: Store? = null) {
        eq.enabled = enabled
        eq.setGains(gains)
        eq.balance = balance
        applyEffects()
        store?.let {
            it.putBool("eq_on", enabled)
            it.put("eq_g", gains.joinToString(","))
            it.putInt("eq_bass", bass)
            it.putInt("eq_virt", virt)
            it.put("eq_bal", balance.toString())
            it.put("eq_preset", preset)
        }
    }

    fun restore(s: Store) {
        enabled = s.bool("eq_on", true)
        val g = s.str("eq_g").split(",").mapNotNull { it.toFloatOrNull() }
        gains = if (g.size == 10) g.toFloatArray() else FloatArray(10)
        bass = s.int("eq_bass", 0)
        virt = s.int("eq_virt", 0)
        balance = s.str("eq_bal", "0").toFloatOrNull() ?: 0f
        preset = s.str("eq_preset", "Flat")
        crossfadeMs = s.int("xfade", 0) * 1000L
        apply()
    }
}
