package com.zymp.musicplayer.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val dateAdded: Long,
    val path: String,
    val mime: String?
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    val artUri: Uri get() = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), albumId)
    val folder: String get() = path.substringBeforeLast('/', "")

    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title).setArtist(artist).setAlbumTitle(album)
                .setArtworkUri(artUri).build()
        ).build()
}

/** Tiny SharedPreferences wrapper used for settings, playlists, favorites, history, EQ presets. */
class Store(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("zymp", Context.MODE_PRIVATE)
    fun str(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun int(k: String, d: Int): Int = sp.getInt(k, d)
    fun putInt(k: String, v: Int) { sp.edit().putInt(k, v).apply() }
    fun bool(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun putBool(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun remove(k: String) { sp.edit().remove(k).apply() }
    fun longList(k: String): List<Long> = str(k).split(",").mapNotNull { it.toLongOrNull() }
    fun putLongList(k: String, l: List<Long>) = put(k, l.joinToString(","))
}

class MusicRepository(private val context: Context) {
    /** Scans MediaStore for audio (MP3, FLAC, WAV, AAC, OGG... anything the OS indexes as music). */
    suspend fun scan(minSeconds: Int): List<Song> = withContext(Dispatchers.IO) {
        val out = ArrayList<Song>()
        val a = MediaStore.Audio.Media
        val proj = arrayOf(a._ID, a.TITLE, a.ARTIST, a.ALBUM, a.ALBUM_ID, a.DURATION, a.DATE_ADDED, a.DATA, a.MIME_TYPE)
        val sel = "${a.IS_MUSIC} != 0 AND ${a.DURATION} >= ?"
        val args = arrayOf((minSeconds * 1000L).toString())
        try {
            context.contentResolver.query(a.EXTERNAL_CONTENT_URI, proj, sel, args, "${a.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val iId = c.getColumnIndexOrThrow(a._ID)
                val iTitle = c.getColumnIndexOrThrow(a.TITLE)
                val iArtist = c.getColumnIndexOrThrow(a.ARTIST)
                val iAlbum = c.getColumnIndexOrThrow(a.ALBUM)
                val iAlbumId = c.getColumnIndexOrThrow(a.ALBUM_ID)
                val iDur = c.getColumnIndexOrThrow(a.DURATION)
                val iAdded = c.getColumnIndexOrThrow(a.DATE_ADDED)
                val iData = c.getColumnIndexOrThrow(a.DATA)
                val iMime = c.getColumnIndexOrThrow(a.MIME_TYPE)
                while (c.moveToNext()) {
                    val artist = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: "Unknown artist"
                    out.add(
                        Song(
                            id = c.getLong(iId),
                            title = c.getString(iTitle) ?: "Unknown",
                            artist = artist,
                            album = c.getString(iAlbum) ?: "Unknown album",
                            albumId = c.getLong(iAlbumId),
                            durationMs = c.getLong(iDur),
                            dateAdded = c.getLong(iAdded),
                            path = c.getString(iData) ?: "",
                            mime = c.getString(iMime)
                        )
                    )
                }
            }
        } catch (_: SecurityException) { }
        out
    }
}
