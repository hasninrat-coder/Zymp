@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package com.zymp.musicplayer.playback

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.zymp.musicplayer.MainActivity
import com.zymp.musicplayer.audio.Fx
import com.zymp.musicplayer.data.Store
import kotlin.math.abs
import kotlin.math.min

class PlaybackService : MediaSessionService() {
    companion object { @Volatile var instance: PlaybackService? = null }

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())
    private var lastVol = 1f

    private val tick = object : Runnable {
        override fun run() {
            val p = player
            val at = Fx.sleepAtMs
            if (at > 0 && System.currentTimeMillis() >= at) {
                Fx.sleepAtMs = 0
                p.pause()
                p.volume = 1f; lastVol = 1f
                return
            }
            val fade = Fx.crossfadeMs
            var v = 1f
            if (fade > 0) {
                val d = p.duration
                if (d != C.TIME_UNSET && d > fade * 3) {
                    val pos = p.currentPosition
                    v = min(1f, min(pos.toFloat() / fade, (d - pos).toFloat() / fade)).coerceIn(0f, 1f)
                }
            }
            if (abs(v - lastVol) > 0.01f) { p.volume = v; lastVol = v }
            if (p.isPlaying) handler.postDelayed(this, 100)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val store = Store(this)
        Fx.restore(store)

        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setEnableFloatOutput(false)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .setAudioProcessors(arrayOf<AudioProcessor>(Fx.eq))
                .build()
        }

        player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                true // audio focus handled by ExoPlayer
            )
            .setHandleAudioBecomingNoisy(store.bool("noisy", true))
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                handler.removeCallbacks(tick)
                if (isPlaying) handler.post(tick)
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) { Fx.attach(audioSessionId) }
        })
        Fx.attach(player.audioSessionId)

        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player).setSessionActivity(pi).build()
    }

    fun setNoisy(v: Boolean) { player.setHandleAudioBecomingNoisy(v) }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.playWhenReady || player.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacks(tick)
        Fx.release()
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
