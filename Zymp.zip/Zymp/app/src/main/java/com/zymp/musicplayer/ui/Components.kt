package com.zymp.musicplayer.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zymp.musicplayer.data.Song
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

object ArtCache {
    private val cache = object : LruCache<String, Bitmap>(12 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount / 1024
    }
    private val misses = HashSet<String>()
    fun key(s: Song, px: Int) = "${if (s.albumId != 0L) "a${s.albumId}" else "s${s.id}"}_$px"
    fun get(k: String): Bitmap? = cache.get(k)
    fun put(k: String, b: Bitmap) { cache.put(k, b) }
    fun missed(k: String) = synchronized(misses) { k in misses }
    fun markMiss(k: String) { synchronized(misses) { misses.add(k) } }
    fun load(ctx: Context, s: Song, px: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) ctx.contentResolver.loadThumbnail(s.uri, Size(px, px), null)
        else ctx.contentResolver.openInputStream(s.artUri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 })
        }
    } catch (_: Exception) { null }
}

@Composable
fun Artwork(song: Song?, modifier: Modifier = Modifier, px: Int = 256, corner: Dp = 12.dp) {
    val ctx = LocalContext.current
    val key = song?.let { ArtCache.key(it, px) }
    var bmp by remember(key) { mutableStateOf(key?.let { ArtCache.get(it) }) }
    LaunchedEffect(key) {
        if (song != null && key != null && bmp == null && !ArtCache.missed(key)) {
            val b = withContext(Dispatchers.IO) { ArtCache.load(ctx, song, px) }
            if (b != null) { ArtCache.put(key, b); bmp = b } else ArtCache.markMiss(key)
        }
    }
    Box(
        modifier.clip(RoundedCornerShape(corner))
            .background(Brush.linearGradient(listOf(Color(0xFF2A1B4D), Color(0xFF0A3A44)))),
        contentAlignment = Alignment.Center
    ) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Rounded.MusicNote, null, Modifier.fillMaxSize(0.5f), tint = Color.White.copy(alpha = .5f))
    }
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun NameDialog(title: String, initial: String, confirm: String, onConfirm: (String) -> Boolean, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    var err by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(text, { text = it; err = false }, singleLine = true, isError = err,
                supportingText = { if (err) Text("Name is empty, reserved or already used") })
        },
        confirmButton = { TextButton({ if (onConfirm(text)) onDismiss() else err = true }) { Text(confirm) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun AddToPlaylistDialog(vm: MainViewModel, song: Song, onDismiss: () -> Unit) {
    val pls by vm.playlists.collectAsStateWithLifecycle()
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        NameDialog("New playlist", "", "Create", { n -> vm.createPlaylist(n).also { ok -> if (ok) vm.addToPlaylist(n.trim(), song.id) } }, onDismiss)
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            Column {
                TextButton({ creating = true }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(8.dp)); Text("New playlist") }
                pls.keys.forEach { name ->
                    TextButton({ vm.addToPlaylist(name, song.id); onDismiss() }, Modifier.fillMaxWidth()) {
                        Text(name, Modifier.fillMaxWidth(), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("Close") } }
    )
}

@Composable
fun SongList(songs: List<Song>, vm: MainViewModel, modifier: Modifier = Modifier, onRemove: ((Song) -> Unit)? = null) {
    val cur by vm.current.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    var pickFor by remember { mutableStateOf<Song?>(null) }
    pickFor?.let { AddToPlaylistDialog(vm, it) { pickFor = null } }
    if (songs.isEmpty()) { EmptyState("Nothing here yet"); return }
    LazyColumn(modifier, contentPadding = PaddingValues(bottom = 12.dp)) {
        itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
            var menu by remember { mutableStateOf(false) }
            val isCur = cur?.id == s.id
            Row(
                Modifier.fillMaxWidth().clickable { vm.play(songs, i) }.padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Artwork(s, Modifier.size(52.dp), 128, 10.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (isCur) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    Text("${s.artist} • ${s.album}", style = MaterialTheme.typography.bodySmall, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(fmt(s.durationMs), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Play next") }, { vm.playNext(s); menu = false })
                        DropdownMenuItem({ Text("Add to queue") }, { vm.addToQueue(s); menu = false })
                        DropdownMenuItem({ Text(if (s.id in favs) "Remove from favorites" else "Add to favorites") }, { vm.toggleFav(s.id); menu = false })
                        DropdownMenuItem({ Text("Add to playlist") }, { pickFor = s; menu = false })
                        if (onRemove != null) DropdownMenuItem({ Text("Remove from this playlist") }, { onRemove(s); menu = false })
                    }
                }
            }
        }
    }
}

@Composable
fun MiniPlayer(vm: MainViewModel, onOpen: () -> Unit) {
    val s by vm.current.collectAsStateWithLifecycle()
    val playing by vm.isPlaying.collectAsStateWithLifecycle()
    val song = s ?: return
    val pos by produceState(0L to 0L, song.id) { while (true) { value = vm.position() to vm.duration(); delay(500) } }
    var dx by remember { mutableFloatStateOf(0f) }
    Column(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(song.id) {
                detectHorizontalDragGestures(
                    onDragEnd = { if (dx > 120) vm.prev() else if (dx < -120) vm.next(); dx = 0f },
                    onDragCancel = { dx = 0f }
                ) { _, d -> dx += d }
            }
    ) {
        LinearProgressIndicator(
            progress = { if (pos.second > 0) (pos.first.toFloat() / pos.second).coerceIn(0f, 1f) else 0f },
            Modifier.fillMaxWidth().height(2.dp), color = MaterialTheme.colorScheme.primary, trackColor = Color.Transparent
        )
        Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(song, Modifier.size(44.dp), 128, 8.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton({ vm.toggle() }) { Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", Modifier.size(30.dp)) }
            IconButton({ vm.next() }) { Icon(Icons.Rounded.SkipNext, "Next") }
        }
    }
}

@Composable
fun ScreenHeader(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "Back") }
        Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        actions()
    }
}
