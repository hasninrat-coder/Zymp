package com.zymp.musicplayer.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zymp.musicplayer.data.Song

data class Group(val key: String, val title: String, val sub: String, val art: Song?)

@Composable
fun HomeScreen(vm: MainViewModel, openDetail: (String, String) -> Unit, openSettings: () -> Unit) {
    val songs by vm.songs.collectAsStateWithLifecycle()
    val visible by vm.visible.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val sort by vm.sort.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val playlists by vm.playlists.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    var searching by rememberSaveable { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var newPl by remember { mutableStateOf(false) }
    val tabs = listOf("Recent", "Songs", "Albums", "Artists", "Playlists", "Folders", "Favorites", "Added")
    var tab by rememberSaveable { mutableIntStateOf(if (vm.recent.value.isEmpty()) 1 else 0) }

    if (newPl) NameDialog("New playlist", "", "Create", { vm.createPlaylist(it) }, { newPl = false })

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Zymp", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
            IconButton({ searching = !searching; if (!searching) vm.query.value = "" }) {
                Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, "Search")
            }
            Box {
                IconButton({ sortMenu = true }) { Icon(Icons.Rounded.Sort, "Sort") }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    MainViewModel.Sort.values().forEach { s ->
                        DropdownMenuItem({ Text(s.label) }, { vm.setSort(s); sortMenu = false },
                            trailingIcon = { if (s == sort) Icon(Icons.Rounded.Check, null) })
                    }
                }
            }
            IconButton(openSettings) { Icon(Icons.Rounded.Settings, "Settings") }
        }
        if (searching) {
            val fr = remember { FocusRequester() }
            OutlinedTextField(
                query, { vm.query.value = it }, singleLine = true, shape = RoundedCornerShape(28.dp),
                placeholder = { Text("Search songs, artists, albums") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).focusRequester(fr)
            )
            LaunchedEffect(Unit) { fr.requestFocus() }
        }
        ScrollableTabRow(tab, containerColor = androidx.compose.ui.graphics.Color.Transparent, edgePadding = 8.dp, divider = {}) {
            tabs.forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
        }
        Box(Modifier.weight(1f)) {
            if (loading && songs.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else if (songs.isEmpty()) {
                EmptyState("No music found on this device.\nAdd audio files, or lower the minimum track length in Settings.")
            } else when (tab) {
                0 -> {
                    val map = remember(visible) { visible.associateBy { it.id } }
                    val list = remember(recent, map) { recent.mapNotNull { map[it] } }
                    if (list.isEmpty()) EmptyState("Songs you play will show up here") else SongList(list, vm)
                }
                1 -> SongList(visible, vm)
                2 -> {
                    val g = remember(visible) {
                        visible.groupBy { it.albumId }.map { (id, l) -> Group(id.toString(), l[0].album, "${l[0].artist} • ${l.size} songs", l[0]) }
                            .sortedBy { it.title.lowercase() }
                    }
                    GroupList(g) { openDetail("album", it.key) }
                }
                3 -> {
                    val g = remember(visible) {
                        visible.groupBy { it.artist }.map { (a, l) -> Group(a, a, "${l.size} songs", l[0]) }.sortedBy { it.title.lowercase() }
                    }
                    GroupList(g) { openDetail("artist", it.key) }
                }
                4 -> {
                    val byId = remember(songs) { songs.associateBy { it.id } }
                    LazyColumn {
                        item {
                            Row(Modifier.fillMaxWidth().clickable { newPl = true }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.Add, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(16.dp)); Text("New playlist", style = MaterialTheme.typography.titleMedium)
                            }
                        }
                        items(playlists.keys.toList(), key = { it }) { name ->
                            val ids = playlists[name].orEmpty()
                            Row(Modifier.fillMaxWidth().clickable { openDetail("playlist", name) }.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Artwork(ids.firstNotNullOfOrNull { byId[it] }, Modifier.size(56.dp), 160, 12.dp)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${ids.size} songs", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                5 -> {
                    val g = remember(visible) {
                        visible.groupBy { it.folder }.map { (f, l) -> Group(f, f.substringAfterLast('/').ifEmpty { "/" }, "${f.removePrefix("/storage/emulated/0/")} • ${l.size} songs", l[0]) }
                            .sortedBy { it.title.lowercase() }
                    }
                    GroupList(g) { openDetail("folder", it.key) }
                }
                6 -> {
                    val list = remember(visible, favs) { visible.filter { it.id in favs } }
                    if (list.isEmpty()) EmptyState("Tap the heart in the player to add favorites") else SongList(list, vm)
                }
                else -> {
                    val list = remember(visible) { visible.sortedByDescending { it.dateAdded }.take(100) }
                    SongList(list, vm)
                }
            }
        }
    }
}

@Composable
fun GroupList(groups: List<Group>, onClick: (Group) -> Unit) {
    if (groups.isEmpty()) { EmptyState("Nothing here yet"); return }
    LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) {
        items(groups, key = { it.key }) { g ->
            Row(Modifier.fillMaxWidth().clickable { onClick(g) }.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Artwork(g.art, Modifier.size(56.dp), 160, 12.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(g.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(g.sub, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun DetailScreen(vm: MainViewModel, kind: String, key: String, onBack: () -> Unit) {
    val all by vm.songs.collectAsStateWithLifecycle()
    val pls by vm.playlists.collectAsStateWithLifecycle()
    val list = remember(all, pls, kind, key) {
        when (kind) {
            "album" -> all.filter { it.albumId.toString() == key }
            "artist" -> all.filter { it.artist == key }
            "folder" -> all.filter { it.folder == key }
            else -> { val m = all.associateBy { it.id }; pls[key].orEmpty().mapNotNull { m[it] } }
        }
    }
    val title = when (kind) { "album" -> list.firstOrNull()?.album ?: "Album"; "folder" -> key.substringAfterLast('/'); else -> key }
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    if (rename) NameDialog("Rename playlist", key, "Rename", { vm.renamePlaylist(key, it).also { ok -> if (ok) onBack() } }, { rename = false })
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(title, onBack) {
            if (kind == "playlist") Box {
                IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "Menu") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Rename") }, { menu = false; rename = true })
                    DropdownMenuItem({ Text("Delete playlist") }, { menu = false; vm.deletePlaylist(key); onBack() })
                }
            }
        }
        Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.play(list, 0) }, enabled = list.isNotEmpty()) { Icon(Icons.Rounded.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("Play") }
            OutlinedButton({ vm.play(list.shuffled(), 0) }, enabled = list.isNotEmpty()) { Icon(Icons.Rounded.Shuffle, null); Spacer(Modifier.width(4.dp)); Text("Shuffle") }
        }
        SongList(list, vm, Modifier.weight(1f), onRemove = if (kind == "playlist") { s -> vm.removeFromPlaylist(key, s.id) } else null)
    }
}
