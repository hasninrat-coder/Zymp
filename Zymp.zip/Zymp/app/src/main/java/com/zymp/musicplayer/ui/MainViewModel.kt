package com.zymp.musicplayer.ui

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.zymp.musicplayer.audio.EqPresets
import com.zymp.musicplayer.audio.Fx
import com.zymp.musicplayer.data.MusicRepository
import com.zymp.musicplayer.data.Song
import com.zymp.musicplayer.data.Store
import com.zymp.musicplayer.playback.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class EqUi(
    val enabled: Boolean, val gains: List<Float>, val bass: Int,
    val virt: Int, val balance: Float, val preset: String
)

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    enum class Sort(val label: String) { TITLE("Title"), ARTIST("Artist"), ALBUM("Album"), DATE("Date added") }

    private val store = Store(app)
    private val repo = MusicRepository(app)
    private var controller: MediaController? = null
    private var byId: Map<Long, Song> = emptyMap()

    // ---- library ----
    val songs = MutableStateFlow<List<Song>>(emptyList())
    val loading = MutableStateFlow(false)
    val query = MutableStateFlow("")
    val sort = MutableStateFlow(runCatching { Sort.valueOf(store.str("sort", "TITLE")) }.getOrDefault(Sort.TITLE))
    val favorites = MutableStateFlow(store.longList("fav").toSet())
    val recent = MutableStateFlow(store.longList("recent"))
    val playlists = MutableStateFlow(loadPlaylists())

    val visible: StateFlow<List<Song>> = combine(songs, query, sort) { list, q, so ->
        val f = if (q.isBlank()) list else list.filter {
            it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true)
        }
        when (so) {
            Sort.TITLE -> f.sortedBy { it.title.lowercase() }
            Sort.ARTIST -> f.sortedWith(compareBy({ it.artist.lowercase() }, { it.title.lowercase() }))
            Sort.ALBUM -> f.sortedWith(compareBy({ it.album.lowercase() }, { it.title.lowercase() }))
            Sort.DATE -> f.sortedByDescending { it.dateAdded }
        }
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ---- settings ----
    val accent = MutableStateFlow(store.int("accent", 0))
    val amoled = MutableStateFlow(store.bool("amoled", true))
    val crossfadeSec = MutableStateFlow(store.int("xfade", 0))
    val minSeconds = MutableStateFlow(store.int("minsec", 30))
    val noisy = MutableStateFlow(store.bool("noisy", true))

    // ---- player state ----
    val current = MutableStateFlow<Song?>(null)
    val isPlaying = MutableStateFlow(false)
    val shuffle = MutableStateFlow(false)
    val repeat = MutableStateFlow(Player.REPEAT_MODE_OFF)
    val speed = MutableStateFlow(1f)
    val queue = MutableStateFlow<List<Song>>(emptyList())
    val queueIndex = MutableStateFlow(0)
    val sleepAt = MutableStateFlow(0L)

    // ---- equalizer ----
    val eq = MutableStateFlow(run { Fx.restore(store); eqSnapshot() })
    val customPresets = MutableStateFlow(store.str("cp_names").split("\n").filter { it.isNotBlank() })

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(events.containsAny(Player.EVENT_TIMELINE_CHANGED, Player.EVENT_MEDIA_ITEM_TRANSITION))
        }
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            mediaItem?.mediaId?.toLongOrNull()?.let { pushRecent(it) }
        }
    }

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val f = MediaController.Builder(app, token).buildAsync()
        f.addListener({
            try {
                controller = f.get().also { it.addListener(listener) }
                sync(true)
            } catch (_: Exception) { }
        }, ContextCompat.getMainExecutor(app))
    }

    override fun onCleared() {
        controller?.release()
        controller = null
    }

    fun load() {
        viewModelScope.launch {
            loading.value = true
            val list = repo.scan(minSeconds.value)
            songs.value = list
            byId = list.associateBy { it.id }
            loading.value = false
            sync(true)
        }
    }

    private fun songOf(m: MediaItem): Song =
        m.mediaId.toLongOrNull()?.let { byId[it] } ?: Song(
            m.mediaId.toLongOrNull() ?: 0, m.mediaMetadata.title?.toString() ?: "Unknown",
            m.mediaMetadata.artist?.toString() ?: "", m.mediaMetadata.albumTitle?.toString() ?: "",
            0, 0, 0, "", null
        )

    private fun sync(rebuildQueue: Boolean) {
        val c = controller ?: return
        current.value = c.currentMediaItem?.let { songOf(it) }
        isPlaying.value = c.isPlaying
        shuffle.value = c.shuffleModeEnabled
        repeat.value = c.repeatMode
        speed.value = c.playbackParameters.speed
        queueIndex.value = c.currentMediaItemIndex
        if (rebuildQueue) queue.value = (0 until c.mediaItemCount).map { songOf(c.getMediaItemAt(it)) }
    }

    // ---- transport ----
    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        if (list.isEmpty() || index !in list.indices) return
        val start = (index - 250).coerceAtLeast(0)          // window the queue: light on RAM
        val end = minOf(list.size, start + 500)
        c.setMediaItems(list.subList(start, end).map { it.toMediaItem() }, index - start, 0L)
        c.prepare(); c.play()
    }
    fun toggle() { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
    fun next() { controller?.seekToNext() }
    fun prev() { controller?.seekToPrevious() }
    fun seekTo(ms: Long) { controller?.seekTo(ms) }
    fun position(): Long = controller?.currentPosition ?: 0L
    fun duration(): Long = controller?.duration?.takeIf { it > 0 } ?: current.value?.durationMs ?: 0L
    fun toggleShuffle() { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
    fun setSpeed(v: Float) { controller?.setPlaybackSpeed(v) }
    fun setSleep(minutes: Int) {
        val t = if (minutes > 0) System.currentTimeMillis() + minutes * 60_000L else 0L
        Fx.sleepAtMs = t; sleepAt.value = t
    }

    // ---- queue ----
    fun playNext(s: Song) { controller?.let { it.addMediaItem(if (it.mediaItemCount == 0) 0 else it.currentMediaItemIndex + 1, s.toMediaItem()) } }
    fun addToQueue(s: Song) { controller?.addMediaItem(s.toMediaItem()) }
    fun removeFromQueue(i: Int) { controller?.removeMediaItem(i) }
    fun moveInQueue(from: Int, to: Int) { controller?.let { if (to in 0 until it.mediaItemCount) it.moveMediaItem(from, to) } }
    fun jumpTo(i: Int) { controller?.let { it.seekTo(i, 0L); it.play() } }

    // ---- favorites / history ----
    fun toggleFav(id: Long) {
        val n = if (id in favorites.value) favorites.value - id else favorites.value + id
        favorites.value = n; store.putLongList("fav", n.toList())
    }
    private fun pushRecent(id: Long) {
        val n = (listOf(id) + recent.value.filter { it != id }).take(50)
        recent.value = n; store.putLongList("recent", n)
    }
    fun clearHistory() { recent.value = emptyList(); store.putLongList("recent", emptyList()) }

    // ---- playlists ----
    private fun loadPlaylists(): Map<String, List<Long>> =
        store.str("pl_names").split("\n").filter { it.isNotBlank() }.associateWith { store.longList("pl_$it") }
    private fun savePlaylists(m: Map<String, List<Long>>) {
        val old = playlists.value.keys
        (old - m.keys).forEach { store.remove("pl_$it") }
        store.put("pl_names", m.keys.joinToString("\n"))
        m.forEach { (k, v) -> store.putLongList("pl_$k", v) }
        playlists.value = m
    }
    fun createPlaylist(name: String): Boolean {
        val n = name.trim().replace("\n", " ")
        if (n.isEmpty() || playlists.value.containsKey(n)) return false
        savePlaylists(LinkedHashMap(playlists.value).apply { put(n, emptyList()) }); return true
    }
    fun renamePlaylist(old: String, new: String): Boolean {
        val n = new.trim().replace("\n", " ")
        if (n.isEmpty() || (n != old && playlists.value.containsKey(n))) return false
        val m = LinkedHashMap<String, List<Long>>()
        playlists.value.forEach { (k, v) -> m[if (k == old) n else k] = v }
        savePlaylists(m); return true
    }
    fun deletePlaylist(name: String) { savePlaylists(LinkedHashMap(playlists.value).apply { remove(name) }) }
    fun addToPlaylist(name: String, id: Long) {
        val cur = playlists.value[name] ?: return
        if (id in cur) return
        savePlaylists(LinkedHashMap(playlists.value).apply { put(name, cur + id) })
    }
    fun removeFromPlaylist(name: String, id: Long) {
        val cur = playlists.value[name] ?: return
        savePlaylists(LinkedHashMap(playlists.value).apply { put(name, cur - id) })
    }

    // ---- lyrics (user-supplied, stored per song) ----
    fun lyrics(id: Long): String = store.str("lyr_$id")
    fun saveLyrics(id: Long, text: String) { if (text.isBlank()) store.remove("lyr_$id") else store.put("lyr_$id", text) }

    // ---- settings ----
    fun setSort(s: Sort) { sort.value = s; store.put("sort", s.name) }
    fun setAccent(i: Int) { accent.value = i; store.putInt("accent", i) }
    fun setAmoled(v: Boolean) { amoled.value = v; store.putBool("amoled", v) }
    fun setCrossfade(sec: Int) { crossfadeSec.value = sec; store.putInt("xfade", sec); Fx.crossfadeMs = sec * 1000L }
    fun setMinSeconds(s: Int) { minSeconds.value = s; store.putInt("minsec", s) }
    fun setNoisy(v: Boolean) { noisy.value = v; store.putBool("noisy", v); PlaybackService.instance?.setNoisy(v) }

    // ---- equalizer ----
    private fun eqSnapshot() = EqUi(Fx.enabled, Fx.gains.toList(), Fx.bass, Fx.virt, Fx.balance, Fx.preset)
    private fun pushEq() { Fx.apply(store); eq.value = eqSnapshot() }
    fun setEqEnabled(v: Boolean) { Fx.enabled = v; pushEq() }
    fun setBand(i: Int, g: Float) { Fx.gains = Fx.gains.copyOf().also { it[i] = g }; Fx.preset = "Custom"; pushEq() }
    fun setBass(v: Int) { Fx.bass = v; pushEq() }
    fun setVirt(v: Int) { Fx.virt = v; pushEq() }
    fun setBalance(v: Float) { Fx.balance = v; pushEq() }
    fun resetEq() { Fx.gains = FloatArray(10); Fx.bass = 0; Fx.virt = 0; Fx.balance = 0f; Fx.preset = "Flat"; pushEq() }
    fun selectPreset(name: String) {
        if (name == "Custom") { Fx.preset = "Custom"; pushEq(); return }
        val g = EqPresets.builtin[name]
            ?: store.str("cp_$name").split(",").mapNotNull { it.toFloatOrNull() }.takeIf { it.size == 10 }?.toFloatArray()
            ?: return
        Fx.gains = g.copyOf(); Fx.preset = name; pushEq()
    }
    fun saveCustomPreset(name: String): Boolean {
        val n = name.trim().replace("\n", " ")
        if (n.isEmpty() || n in EqPresets.builtin.keys || n.equals("Custom", true)) return false
        store.put("cp_$n", Fx.gains.joinToString(","))
        if (n !in customPresets.value) {
            customPresets.value = customPresets.value + n
            store.put("cp_names", customPresets.value.joinToString("\n"))
        }
        Fx.preset = n; pushEq(); return true
    }
    fun deleteCustomPreset(name: String) {
        store.remove("cp_$name")
        customPresets.value = customPresets.value - name
        store.put("cp_names", customPresets.value.joinToString("\n"))
        if (Fx.preset == name) Fx.preset = "Custom"
        pushEq()
    }
}
