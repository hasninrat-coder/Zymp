package com.zymp.musicplayer.ui

import android.content.Context
import android.media.AudioManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(vm: MainViewModel, onClose: () -> Unit, onEq: () -> Unit, onLyrics: () -> Unit) {
    val song by vm.current.collectAsStateWithLifecycle()
    val playing by vm.isPlaying.collectAsStateWithLifecycle()
    val shuffle by vm.shuffle.collectAsStateWithLifecycle()
    val repeat by vm.repeat.collectAsStateWithLifecycle()
    val speed by vm.speed.collectAsStateWithLifecycle()
    val favs by vm.favorites.collectAsStateWithLifecycle()
    val sleepAt by vm.sleepAt.collectAsStateWithLifecycle()
    val queue by vm.queue.collectAsStateWithLifecycle()
    val qIndex by vm.queueIndex.collectAsStateWithLifecycle()
    val s = song ?: return
    val ctx = LocalContext.current
    val primary = MaterialTheme.colorScheme.primary
    var showQueue by remember { mutableStateOf(false) }
    var showSpeed by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }

    // position / duration polling
    val pd by produceState(0L to 0L, s.id) { while (true) { value = vm.position() to vm.duration(); delay(250) } }
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(0f) }
    val dur = pd.second.coerceAtLeast(1L)
    val shownPos = if (dragging) dragPos else pd.first.toFloat().coerceIn(0f, dur.toFloat())

    // volume
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()
    var vol by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    LaunchedEffect(Unit) { while (true) { vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat(); delay(600) } }

    val remain by produceState(0L, sleepAt) { while (true) { value = if (sleepAt > 0) (sleepAt - System.currentTimeMillis()).coerceAtLeast(0) else 0; delay(1000) } }

    val scale by animateFloatAsState(if (playing) 1f else .86f, spring(dampingRatio = .6f), label = "art")
    var dragX by remember { mutableFloatStateOf(0f) }

    if (showSpeed) AlertDialog(
        onDismissRequest = { showSpeed = false }, title = { Text("Playback speed") },
        text = { Column { listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { v ->
            TextButton({ vm.setSpeed(v); showSpeed = false }, Modifier.fillMaxWidth()) {
                Text("${v}x" + if (v == speed) "  ✓" else "", Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
            } } } },
        confirmButton = {}, dismissButton = { TextButton({ showSpeed = false }) { Text("Close") } })
    if (showSleep) AlertDialog(
        onDismissRequest = { showSleep = false }, title = { Text("Sleep timer") },
        text = { Column { listOf(0, 15, 30, 45, 60, 90).forEach { m ->
            TextButton({ vm.setSleep(m); showSleep = false }, Modifier.fillMaxWidth()) {
                Text(if (m == 0) "Off" else "$m minutes", Modifier.fillMaxWidth(), textAlign = TextAlign.Start)
            } } } },
        confirmButton = {}, dismissButton = { TextButton({ showSleep = false }) { Text("Close") } })

    if (showQueue) ModalBottomSheet(onDismissRequest = { showQueue = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Text("Queue (${queue.size})", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        LazyColumn(Modifier.fillMaxWidth()) {
            itemsIndexed(queue) { i, q ->
                Row(Modifier.fillMaxWidth().clickable { vm.jumpTo(i) }.padding(start = 16.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Artwork(q, Modifier.size(44.dp), 128, 8.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(q.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (i == qIndex) primary else MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.titleMedium)
                        Text(q.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton({ vm.moveInQueue(i, i - 1) }, enabled = i > 0) { Icon(Icons.Rounded.KeyboardArrowUp, "Move up") }
                    IconButton({ vm.moveInQueue(i, i + 1) }, enabled = i < queue.lastIndex) { Icon(Icons.Rounded.KeyboardArrowDown, "Move down") }
                    IconButton({ vm.removeFromQueue(i) }) { Icon(Icons.Rounded.Close, "Remove") }
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(primary.copy(alpha = .38f), MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.background)))
            .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close", Modifier.size(32.dp)) }
            Text("Now Playing", Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            IconButton({ showQueue = true }) { Icon(Icons.Rounded.QueueMusic, "Queue") }
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f)
                .graphicsLayer { scaleX = scale; scaleY = scale; translationX = dragX * .35f }
                .pointerInput(s.id) {
                    detectHorizontalDragGestures(
                        onDragEnd = { if (dragX > 150) vm.prev() else if (dragX < -150) vm.next(); dragX = 0f },
                        onDragCancel = { dragX = 0f }
                    ) { _, d -> dragX += d }
                }
        ) {
            AnimatedContent(s, transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(300)) }, contentKey = { it.id }, label = "art") { sg ->
                Artwork(sg, Modifier.fillMaxSize(), 768, 28.dp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.title, style = MaterialTheme.typography.titleLarge.copy(fontSize = 24.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(s.artist, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            val fav = s.id in favs
            IconButton({ vm.toggleFav(s.id) }) {
                Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorite", tint = if (fav) primary else Color.White, modifier = Modifier.size(28.dp))
            }
        }
        Slider(
            value = shownPos, valueRange = 0f..dur.toFloat(),
            onValueChange = { dragging = true; dragPos = it },
            onValueChangeFinished = { vm.seekTo(dragPos.toLong()); dragging = false }
        )
        Row(Modifier.fillMaxWidth().offset(y = (-8).dp)) {
            Text(fmt(shownPos.toLong()), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Text(fmt(dur), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ vm.toggleShuffle() }) { Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (shuffle) primary else Color.White) }
            IconButton({ vm.prev() }, Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(38.dp)) }
            FilledIconButton({ vm.toggle() }, Modifier.size(72.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = primary, contentColor = Color.Black)) {
                Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, "Play/Pause", Modifier.size(42.dp))
            }
            IconButton({ vm.next() }, Modifier.size(56.dp)) { Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(38.dp)) }
            IconButton({ vm.cycleRepeat() }) {
                Icon(if (repeat == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Repeat",
                    tint = if (repeat != Player.REPEAT_MODE_OFF) primary else Color.White)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.VolumeUp, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(vol, { vol = it; am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0) }, Modifier.weight(1f).padding(start = 8.dp), valueRange = 0f..maxVol)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            SmallAction(Icons.Rounded.Speed, "${speed}x", speed != 1f) { showSpeed = true }
            SmallAction(Icons.Rounded.Timer, if (remain > 0) "${(remain / 60000) + 1}m" else "Sleep", remain > 0) { showSleep = true }
            SmallAction(Icons.Rounded.Equalizer, "EQ", false, onEq)
            SmallAction(Icons.Rounded.Notes, "Lyrics", vm.lyrics(s.id).isNotBlank(), onLyrics)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SmallAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, label = "tint")
    Column(Modifier.clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = tint)
        Text(label, style = MaterialTheme.typography.bodySmall, color = tint)
    }
}
