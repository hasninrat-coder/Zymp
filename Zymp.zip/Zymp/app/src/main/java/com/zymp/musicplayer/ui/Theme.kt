package com.zymp.musicplayer.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val Accents = listOf(Color(0xFF9B4DFF), Color(0xFF00E5FF), Color(0xFFFF4081), Color(0xFF00E676), Color(0xFFFF9100))
val ZCyan = Color(0xFF00E5FF)

fun fmt(ms: Long): String {
    val s = (ms.coerceAtLeast(0)) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun ZympTheme(accent: Color, amoled: Boolean, content: @Composable () -> Unit) {
    val bg = if (amoled) Color.Black else Color(0xFF121212)
    val surf = if (amoled) Color(0xFF0E0E10) else Color(0xFF1C1C1E)
    val scheme = darkColorScheme(
        primary = accent, onPrimary = Color.Black,
        secondary = ZCyan, onSecondary = Color.Black,
        background = bg, onBackground = Color.White,
        surface = surf, onSurface = Color.White,
        surfaceVariant = Color(0xFF26262B), onSurfaceVariant = Color(0xFFB8B8C0),
        surfaceContainerLow = surf, surfaceContainer = surf, surfaceContainerHigh = Color(0xFF1E1E22)
    )
    val f = FontFamily.SansSerif
    val type = Typography(
        headlineMedium = TextStyle(fontFamily = f, fontWeight = FontWeight.Black, fontSize = 30.sp, letterSpacing = (-0.5).sp),
        titleLarge = TextStyle(fontFamily = f, fontWeight = FontWeight.Bold, fontSize = 22.sp),
        titleMedium = TextStyle(fontFamily = f, fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
        bodyMedium = TextStyle(fontFamily = f, fontSize = 14.sp),
        bodySmall = TextStyle(fontFamily = f, fontSize = 12.sp),
        labelLarge = TextStyle(fontFamily = f, fontWeight = FontWeight.Medium, fontSize = 14.sp)
    )
    MaterialTheme(colorScheme = scheme, typography = type, content = content)
}
