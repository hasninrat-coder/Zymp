package com.zymp.musicplayer.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.zymp.musicplayer.audio.EqPresets
import com.zymp.musicplayer.audio.Fx

@Composable
private fun VerticalSlider(value: Float, onChange: (Float) -> Unit, range: ClosedFloatingPointRange<Float>, enabled: Boolean) {
    Slider(
        value, onChange, enabled = enabled, valueRange = range,
        modifier = Modifier
            .graphicsLayer { rotationZ = 270f; transformOrigin = TransformOrigin(0f, 0f) }
            .layout { measurable, constraints ->
                val p = measurable.measure(Constraints(constraints.minHeight, constraints.maxHeight, constraints.minWidth, constraints.maxWidth))
                layout(p.height, p.width) { p.place(-p.width, 0) }
            }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerScreen(vm: MainViewModel, onBack: () -> Unit) {
    val eq by vm.eq.collectAsStateWithLifecycle()
    val customs by vm.customPresets.collectAsStateWithLifecycle()
    var saving by remember { mutableStateOf(false) }
    if (saving) NameDialog("Save preset", "", "Save", { vm.saveCustomPreset(it) }, { saving = false })
    val names = EqPresets.builtin.keys.toList() + customs + "Custom"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Equalizer", onBack) { Switch(eq.enabled, { vm.setEqEnabled(it) }, Modifier.padding(end = 12.dp)) }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(names) { n -> FilterChip(eq.preset == n, { vm.selectPreset(n) }, { Text(n) }) }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
            for (i in 0 until 10) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("%+.0f".format(eq.gains[i]), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    Box(Modifier.height(200.dp).width(36.dp), contentAlignment = Alignment.Center) {
                        VerticalSlider(eq.gains[i], { vm.setBand(i, Math.round(it).toFloat()) }, -12f..12f, eq.enabled)
                    }
                    Text(EqPresets.labels[i], style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Text("dB  •  Hz", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Bass Boost  ${eq.bass / 10}%", style = MaterialTheme.typography.titleMedium)
            Slider(eq.bass.toFloat(), { vm.setBass(it.toInt()) }, valueRange = 0f..1000f, enabled = eq.enabled && Fx.bassOk)
            if (!Fx.bassOk) Text("Not supported by this device's audio driver", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Virtualizer  ${eq.virt / 10}%", style = MaterialTheme.typography.titleMedium)
            Slider(eq.virt.toFloat(), { vm.setVirt(it.toInt()) }, valueRange = 0f..1000f, enabled = eq.enabled && Fx.virtOk)
            if (!Fx.virtOk) Text("Not supported by this device's audio driver", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            val bl = when { eq.balance < -0.01f -> "L ${(-eq.balance * 100).toInt()}%"; eq.balance > 0.01f -> "R ${(eq.balance * 100).toInt()}%"; else -> "Center" }
            Text("Balance  $bl", style = MaterialTheme.typography.titleMedium)
            Slider(eq.balance, { vm.setBalance(if (kotlin.math.abs(it) < 0.04f) 0f else it) }, valueRange = -1f..1f)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ vm.resetEq() }) { Icon(Icons.Rounded.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Reset") }
                Button({ saving = true }) { Text("Save preset") }
                if (eq.preset in customs) TextButton({ vm.deleteCustomPreset(eq.preset) }) { Icon(Icons.Rounded.Delete, null); Spacer(Modifier.width(4.dp)); Text("Delete") }
            }
        }
    }
}

@Composable
fun LyricsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val song by vm.current.collectAsStateWithLifecycle()
    val s = song
    var text by remember(s?.id) { mutableStateOf(s?.let { vm.lyrics(it.id) } ?: "") }
    var saved by remember { mutableStateOf(false) }
    var editing by remember(s?.id) { mutableStateOf(text.isBlank()) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Lyrics", onBack) {
            if (s != null) TextButton({
                if (editing) { vm.saveLyrics(s.id, text); saved = true; editing = text.isBlank() } else editing = true
            }) { Text(if (editing) "Save" else "Edit") }
        }
        if (s == null) { EmptyState("Play a song to view its lyrics"); return@Column }
        Text(s.title, Modifier.padding(horizontal = 20.dp), style = MaterialTheme.typography.titleMedium)
        Text(s.artist, Modifier.padding(horizontal = 20.dp, vertical = 2.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        if (editing) {
            OutlinedTextField(text, { text = it; saved = false }, Modifier.fillMaxSize().padding(16.dp), placeholder = { Text("Paste or type lyrics for this song…") })
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
                Text(text, style = MaterialTheme.typography.titleLarge.copy(lineHeight = androidx.compose.ui.unit.TextUnit(32f, androidx.compose.ui.unit.TextUnitType.Sp)))
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit, onEq: () -> Unit) {
    val ctx = LocalContext.current
    val accent by vm.accent.collectAsStateWithLifecycle()
    val amoled by vm.amoled.collectAsStateWithLifecycle()
    val xfade by vm.crossfadeSec.collectAsStateWithLifecycle()
    val minSec by vm.minSeconds.collectAsStateWithLifecycle()
    val noisy by vm.noisy.collectAsStateWithLifecycle()
    val songs by vm.songs.collectAsStateWithLifecycle()
    var minDraft by remember(minSec) { mutableFloatStateOf(minSec.toFloat()) }

    @Composable fun Section(t: String) = Text(t, Modifier.padding(start = 20.dp, top = 20.dp, bottom = 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader("Settings", onBack)
        Section("Theme")
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AMOLED black", style = MaterialTheme.typography.titleMedium)
                Text(if (amoled) "Pure black background" else "Dark gray background", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(amoled, { vm.setAmoled(it) })
        }
        Text("Accent color", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.titleMedium)
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Accents.forEachIndexed { i, c ->
                Box(Modifier.size(42.dp).clip(CircleShape).background(c)
                    .then(if (i == accent) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                    .clickable { vm.setAccent(i) })
            }
        }
        Section("Audio")
        SettingRow("Equalizer", "10-band EQ, bass boost, virtualizer, balance", onEq)
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Text("Crossfade: " + if (xfade == 0) "Off" else "${xfade}s", style = MaterialTheme.typography.titleMedium)
            Text("Fades out the end of a track and fades the next one in. Gapless playback is always on when Off.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(xfade.toFloat(), { vm.setCrossfade(it.toInt()) }, valueRange = 0f..12f, steps = 11)
        }
        Section("Playback")
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Pause when headphones disconnect", style = MaterialTheme.typography.titleMedium)
                Text("Applies to wired and Bluetooth output", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(noisy, { vm.setNoisy(it) })
        }
        SettingRow("Clear play history", "Empties the Recent tab") { vm.clearHistory() }
        Section("Library")
        Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
            Text("Ignore tracks shorter than ${minDraft.toInt()}s", style = MaterialTheme.typography.titleMedium)
            Slider(minDraft, { minDraft = it }, valueRange = 0f..120f, onValueChangeFinished = { vm.setMinSeconds(minDraft.toInt()) })
        }
        SettingRow("Rescan library", "${songs.size} songs found") { vm.load() }
        Section("Notifications")
        SettingRow("Notification settings", "Open system settings for Zymp") {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        Section("About Zymp")
        Text("Zymp 1.0\nAn original music player built with Jetpack Compose and AndroidX Media3.\ncom.zymp.musicplayer", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun SettingRow(title: String, sub: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
